
import 'package:flutter/material.dart';
import '../api_service.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String userId = '';
  bool isSharing = false;
  double gbShared = 0.0;
  double earned = 0.0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    userId = ModalRoute.of(context)!.settings.arguments as String;
    fetchStats();
  }

  void fetchStats() async {
    var stats = await ApiService.getStats(userId);
    if (stats != null) {
      setState(() {
        gbShared = stats['gb_shared'];
        earned = stats['earned'];
      });
    }
  }

  void toggleSharing() async {
    setState(() => isSharing = !isSharing);
    if (isSharing) {
      await ApiService.updateUsage(userId, 0.1);
      fetchStats();
    }
  }

  void requestPayout() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Request Payout"),
        content: Text("Are you sure you want to request a payout of \$${earned.toStringAsFixed(2)}?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              // Implement payout logic
              Navigator.of(context).pop();
            },
            child: Text("Confirm"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 5.0,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      "Bandwidth Sharing Stats",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("GB Shared: ${gbShared.toStringAsFixed(2)} GB"),
                        ElevatedButton(
                          onPressed: toggleSharing,
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                              isSharing ? Colors.green : Colors.red,
                            ),
                          ),
                          child: Text(isSharing ? 'Stop Sharing' : 'Start Sharing'),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Earned: \$${earned.toStringAsFixed(2)}"),
                        ElevatedButton(
                          onPressed: requestPayout,
                          child: Text("Request Payout"),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
