import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const baseUrl = 'http://10.0.2.2:5000'; // Replace with your backend URL if deployed

  static Future<String?> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({"email": email, "password": password}),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['user_id'];
    }
    return null;
  }

  static Future<String?> register(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({"email": email, "password": password}),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['user_id'];
    }
    return null;
  }

  static Future<bool> updateUsage(String userId, double gb) async {
    final response = await http.post(
      Uri.parse('$baseUrl/update-usage'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({"user_id": userId, "gb": gb}),
    );
    return response.statusCode == 200;
  }

  static Future<Map<String, dynamic>?> getStats(String userId) async {
    final response = await http.get(Uri.parse('$baseUrl/get-stats?user_id=$userId'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return null;
  }
}